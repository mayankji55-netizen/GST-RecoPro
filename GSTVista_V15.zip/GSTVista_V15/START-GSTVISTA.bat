@echo off
setlocal
cd /d "%~dp0"
title GSTVista - Local Server

echo ==========================================
echo          GSTVista - Local Test
echo ==========================================
echo.
echo Starting:
echo http://127.0.0.1:5501/
echo.
echo Keep this window open while GSTVista is running.
echo Press Ctrl+C to stop.
echo.

start "" http://127.0.0.1:5501/
python -m http.server 5501
