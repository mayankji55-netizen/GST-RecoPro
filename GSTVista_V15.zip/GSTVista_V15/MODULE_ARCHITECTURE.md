# GSTVista Full Linked Architecture

All pages remain linked through the shared session/navigation layer.

Page-specific files:
- company.html / company.css / company.js
- party-master.html / party-master.css / party-master.js
- gst-home.html / gst-home.css / gst-home.js
- gstr2b.html / gstr2b.css / gstr2b.js
- ims.html / ims.css / ims.js
- books.html / books.css / books.js
- reconciliation.html / reconciliation.css / reconciliation.js
- reports.html / reports.css / reports.js
- utilities.html / utilities.css / utilities.js

Shared:
- js/core.js
- js/modules/shared-ui.js
- js/modules/import-engine.js
- js/modules/matching-engine.js

Rule: change a page's CSS/JS only for that page unless the change is genuinely shared.
