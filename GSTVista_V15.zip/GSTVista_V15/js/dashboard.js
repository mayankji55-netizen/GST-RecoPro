
/* GSTVista Dashboard — page-only logic */
function showComingSoon(name){
  let e=document.getElementById('gvComingSoon');
  if(!e){
    e=document.createElement('div'); e.id='gvComingSoon';
    e.innerHTML=`<div class="box"><h3>${name} — Coming Soon</h3><p>This GSTVista module is under development.</p><button type="button" onclick="closeComingSoon()">OK</button></div>`;
    document.body.appendChild(e);
  }
  e.classList.add('show');
}
function closeComingSoon(){document.getElementById('gvComingSoon')?.classList.remove('show')}

function getDashboardClients(){
  try{return JSON.parse(localStorage.getItem('gstvista_clients')||'[]')}catch(e){return []}
}
function renderClientList(){
  const list=document.getElementById('gvClientList'); if(!list)return;
  const clients=getDashboardClients();
  if(!clients.length){list.innerHTML='<div class="client-list-empty">No clients created yet.</div>';return}
  list.innerHTML=clients.map((c,i)=>{
    const name=c.name||c.companyName||c.clientName||('Client '+(i+1));
    const gst=c.gstin||c.GSTIN||'';
    return `<button class="client-row" type="button" onclick="openClientDetail(${i})">${escapeHtml(name)}${gst?`<small>${escapeHtml(gst)}</small>`:''}</button>`;
  }).join('');
}
function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function openClientDetail(i){
  const c=getDashboardClients()[i]; if(!c)return;
  let e=document.getElementById('gvClientDetail');
  if(!e){
    e=document.createElement('div');e.id='gvClientDetail';
    e.innerHTML='<div class="box"><div class="head"><span id="gvClientTitle"></span><button onclick="closeClientDetail()">×</button></div><div class="body"><div class="grid" id="gvClientGrid"></div></div></div>';
    e.onclick=(ev)=>{if(ev.target===e)closeClientDetail()};document.body.appendChild(e);
  }
  document.getElementById('gvClientTitle').textContent=c.name||c.companyName||c.clientName||'Client';
  const grid=document.getElementById('gvClientGrid');
  const entries=Object.entries(c);
  grid.innerHTML=entries.length?entries.map(([k,v])=>`<div>${escapeHtml(k)}</div><div>${escapeHtml(typeof v==='object'?JSON.stringify(v):v)}</div>`).join(''):'<div>Client</div><div>No additional data</div>';
  e.classList.add('show');
}
function closeClientDetail(){document.getElementById('gvClientDetail')?.classList.remove('show')}

function renderIndexWorkspace(){
  const e=document.getElementById('main'); if(!e)return;
  e.innerHTML=`
    <div class="dashboard-head">
      <div><h1>GSTVista Workspace</h1><p>Professional GST Automation &amp; Reconciliation Office</p></div>
      <div class="dashboard-actions"><a class="primary" href="pages/gst-home.html">Open GST Office</a></div>
    </div>
    <div class="software-area">
      <section class="software-panel">
        <div class="software-panel-head"><b>Software's</b><span>GSTVista Modules</span></div>
        <div class="software-grid">
          <a class="software-item" href="#" onclick="showComingSoon('Tax');return false;"><div class="soft-icon">₹</div><strong>Tax</strong><small>Coming Soon</small></a>
          <a class="software-item" href="#" onclick="showComingSoon('TDS');return false;"><div class="soft-icon">T</div><strong>TDS</strong><small>Coming Soon</small></a>
          <a class="software-item" href="pages/gst-home.html"><div class="soft-icon">G</div><strong>GST</strong><small>Open GST Office</small></a>
        </div>
      </section>
    </div>`;
  renderClientList();
}
